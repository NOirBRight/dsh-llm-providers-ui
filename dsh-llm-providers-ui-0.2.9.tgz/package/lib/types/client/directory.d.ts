/** Open registration service for Provider card roles and quota readers. */
import type { ProviderUsageReader } from './usage.ts';
export type ProviderRole = 'llm' | 'agent';
/** Who renders the provider card header. Shared cards use the provider-ui header; legacy cards keep the shell fallback badge. */
export type ProviderHeaderOwnership = 'shared' | 'legacy';
/** Who owns the expanded Provider detail layout. */
export type ProviderDetailOwnership = 'shared' | 'legacy';
/** Overview connection only. Never carries an email. `unknown` means the plugin has not resolved auth or credential status yet. */
export interface ProviderAccountSnapshot {
    state: 'connected' | 'configured' | 'unconnected' | 'unknown';
}
/** Native-agent RPC descriptor published by an Agent plugin. Not an execution registry. */
export interface ProviderNativeBinding {
    readonly provider: string;
    readonly channel: string;
    readonly endpoint: string;
}
export interface ProviderDeclaration {
    key: string;
    /** Display name for the overview and detail title; falls back to the card key. */
    name?: string;
    role?: ProviderRole;
    header?: ProviderHeaderOwnership;
    /** Who renders the expanded detail: the shared template, or the legacy card. */
    detail?: ProviderDetailOwnership;
    usage?: ProviderUsageReader;
    account?: () => ProviderAccountSnapshot;
    /** Catalog group id used by the model picker; omit when the card has no picker group. */
    catalogId?: string;
    /** Native-agent binding lookup; omit for LLM cards. */
    binding?: {
        channel: string;
        endpoint: string;
    };
    /** Active model count for the overview subline; omit when the plugin reports none. */
    modelCount?: () => number | undefined;
}
/** Lets client plugins publish their Provider card role and optional quota reader. */
export declare class ProviderDirectory {
    private readonly entries;
    private readonly listeners;
    private readonly invalidationListeners;
    /**
    * Publish a Provider declaration.
    * @param declaration - Card key, role, and optional quota reader.
    * @returns A disposer that removes the declaration.
     * @throws {Error} When the card key, catalog route, or native binding descriptor conflicts with an active registration.
     */
    register(declaration: ProviderDeclaration): () => void;
    /**
     * Read a Provider role, defaulting undeclared cards to LLM.
     * @param key - Provider card key.
     * @returns The published role or LLM for an undeclared card.
     */
    roleOf(key: string): ProviderRole;
    /**
     * Read who renders a Provider header, defaulting undeclared cards to legacy.
     * The shell renders its fallback badge only for legacy cards.
     * @param key - Provider card key.
     * @returns shared for migrated cards, legacy otherwise.
     */
    headerOf(key: string): ProviderHeaderOwnership;
    /**
     * Read the optional quota reader for a Provider card.
     * @param key - Provider card key.
     * @returns The published reader, if any.
     */
    reader(key: string): ProviderUsageReader | undefined;
    /**
     * Read who renders the expanded detail.
     * @param key - Provider card key.
     * @returns shared for migrated cards, legacy otherwise.
     */
    detailOf(key: string): ProviderDetailOwnership;
    /** Display name for the overview and detail title. */
    nameOf(key: string): string | undefined;
    /** Active model count, or undefined when the plugin does not report one. */
    modelCountOf(key: string): number | undefined;
    /**
     * Tell listeners a provider's reported state changed (auth, models, label).
     * @param key - provider card key whose metadata changed.
     */
    update(key: string): void;
    /** Overview connection only. Never returns an email. */
    accountOf(key: string): ProviderAccountSnapshot | undefined;
    /** Live catalog-group-id → card-key map for picker/settings sort. */
    catalogRoutes(): Record<string, string>;
    /**
     * Native-agent binding descriptors. Derived from Agent entries that published both `catalogId` and `binding`.
     * @returns One descriptor per registered native agent; empty when none are declared.
     */
    nativeBindings(): readonly ProviderNativeBinding[];
    /**
     * Subscribe to changes in registered Providers.
     * @param listener - Called after a declaration is added or removed.
     * @returns A disposer that stops notifications.
     */
    subscribe(listener: () => void): () => void;
    /**
     * Signal that cached quota for a key is no longer valid. Providers call
     * this immediately after sign-out or account switch; the shell purges the
     * sidebar cache and refetches, so the previous account's quota never lingers
     * as a stale tile. Transient read errors still show stale data by design.
     * @param key - Provider card key whose quota cache must drop.
     */
    invalidateUsage(key: string): void;
    /**
     * Subscribe to quota-invalidation signals.
     * @param listener - Called with the key whose cache must drop.
     * @returns A disposer that stops notifications.
     */
    onInvalidateUsage(listener: (key: string) => void): () => void;
    private notify;
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        providerDirectory: ProviderDirectory;
    }
}
//# sourceMappingURL=directory.d.ts.map