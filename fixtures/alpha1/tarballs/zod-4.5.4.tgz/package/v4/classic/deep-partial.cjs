"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.deepPartial = deepPartial;
const visit_js_1 = require("../core/visit.cjs");
const schemas = __importStar(require("./schemas.cjs"));
/** Returns a copy of the schema with every nested object's properties made optional. */
function deepPartial(schema) {
    return (0, visit_js_1.visit)(schema, {
        object: (s) => s.partial(),
        // Every partialed option now admits `undefined`, which the constructor rejects as a duplicate.
        union: (s) => {
            const def = s._zod.def;
            return def.discriminator === undefined ? s : schemas.union(def.options);
        },
    });
}
