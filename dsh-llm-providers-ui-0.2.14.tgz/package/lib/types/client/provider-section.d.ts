/** Shared Settings > LLM Providers section. The dsh-llm-providers-ui client owns the nav row. */
/**
 * Canonical window wording, shared by the overview rows and the detail quota block:
 * "Monthly", "Cursor Models · Monthly" and "M" all read as the same full phrase.
 * @param label - the provider-supplied window label.
 * @param names - the locale's canonical hour/week/month phrases.
 * @returns the label to display.
 */
export declare function windowNameOf(label: string, names: {
    readonly hour: string;
    readonly week: string;
    readonly month: string;
}): string;
export { PROVIDERS_SECTION_ID, PROVIDERS_ITEM_SLOT, PROVIDERS_LOCALE_NS, PROVIDERS_CONFIG_ID, PROVIDER_ITEM_ORDER, PROVIDER_ROUTES, applySavedOrder, providerRoute, sortCatalogGroups, } from '../order.js';
export type { CatalogGroup, ProviderItemKey, ProviderOrderSettings } from '../order.js';
/** Locale copy: empty state names all six providers. */
export declare const copy: {
    readonly zh: {
        readonly usageTitle: "供应商额度";
        readonly usageLoading: "加载中…";
        readonly usageEmptyQuota: "暂无额度数据";
        readonly usageLoggedOut: "未登录";
        readonly usageUnsupported: "不支持查询";
        readonly usageStale: "额度已过期";
        readonly usageError: "加载失败";
        readonly usageExpired: "已过期";
        readonly usageShowProvider: "在侧栏显示 {name}";
        readonly usageDetails: "{name} 额度详情";
        readonly usageBack: "返回全部 Provider";
        readonly usageRefreshProvider: "刷新 {name}";
        readonly usageNoProviders: "暂无可查询的 Provider";
        readonly usageNoneVisible: "没有显示的 Provider";
        readonly usageFilterHint: "使用筛选按钮选择要在侧栏显示的 Provider";
        readonly usageOpenFilter: "打开筛选";
        readonly usageChooseProviders: "选择侧栏显示的 Provider";
        readonly usageRefreshAll: "刷新全部";
        readonly usageVisibility: "侧栏显示";
        readonly usageVisibilityHint: "只影响侧栏额度，不影响模型列表";
        readonly usageCloseFilter: "关闭筛选";
        readonly usageSearch: "搜索 Provider";
        readonly usageShowAll: "显示全部 {n} 个";
        readonly usageNoMatch: "没有匹配的 Provider";
        readonly usageReorder: "调整顺序: {name}";
        readonly nav: "LLM 供应商";
        readonly title: "LLM 供应商";
        readonly subtitle: "先看账户额度，再进入独立详情页配置。";
        readonly empty: "安装 Cursor、Grok、Codex、Ollama Cloud、CommandCode 或 OpenCode Go 后，在这里连接账号并选择模型。";
        readonly drag: "拖动排序";
        readonly sort: "Provider 排序";
        readonly done: "完成";
        readonly modelCount: "{n} 个模型";
        readonly moveUp: "上移";
        readonly moveDown: "下移";
        readonly sidebarToggle: "在侧边栏显示";
        readonly sidebarToggleHint: "仅控制 Task Panel 的额度区域";
        readonly filterAll: "全部";
        readonly filterLlm: "LLM";
        readonly filterAgent: "Agent";
        readonly details: "详情";
        readonly overview: "返回总览";
        readonly connected: "已连接";
        readonly configured: "已配置";
        readonly unconnected: "未连接";
        readonly unknown: "正在确认…";
        readonly connectedCount: "已连接的 Provider";
        readonly connectedHint: "额度属于各自账户，不合并统计，也不互相替代。";
        readonly colProvider: "Provider / 连接状态";
        readonly colQuota: "主要窗口 · 剩余额度";
        readonly windowHour: "5 小时窗口";
        readonly windowWeek: "每周窗口";
        readonly windowMonth: "每月窗口";
        readonly colConfig: "配置";
        readonly systemZone: "系统时区";
        readonly breadcrumbOverview: "额度总览";
        readonly quotaHeading: "剩余额度";
        readonly quotaMeta: "账户剩余额度 · 各窗口独立计量";
        readonly connectToSee: "连接后查看额度";
        readonly unsupportedQuota: "暂不支持额度查询";
        readonly loadingQuota: "正在读取额度…";
        readonly errorQuota: "额度读取失败";
        readonly resetAt: "重置于 ";
        readonly resetOverdue: "已到期，等待更新 · ";
        readonly resetMissing: "{period} · 重置时间未提供";
        readonly refresh: "刷新";
        readonly refreshing: "刷新中";
        readonly accountHeading: "账号与连接";
        readonly advancedHeading: "高级设置";
        readonly advancedNote: "可选能力与工具";
        readonly accountOauthMeta: "订阅授权，不使用 API Key";
        readonly accountApiMeta: "API Key · 不会回显已保存的密钥";
        readonly expandAll: "全部展开";
        readonly collapseAll: "全部收起";
        readonly modelIdLabel: "Model ID";
        readonly modelNameLabel: "显示名称";
        readonly addModelLabel: "手动添加模型";
        readonly removeModelLabel: "删除";
        readonly dragModelLabel: "拖动排序";
        readonly modelsHeading: "模型";
        readonly modelsCount: "{n} 个";
        readonly modelsHint: "名称和 ID 始终显示；展开箭头查看容量与能力参数。";
        readonly sortModels: "排序";
        readonly chooseFromAccount: "从账户目录选取";
        readonly addModel: "手动添加模型";
    };
    readonly en: {
        readonly usageTitle: "Provider Usage";
        readonly usageLoading: "Loading…";
        readonly usageEmptyQuota: "No quota data";
        readonly usageLoggedOut: "Signed out";
        readonly usageUnsupported: "Quota unavailable";
        readonly usageStale: "Quota expired";
        readonly usageError: "Could not load quota";
        readonly usageExpired: "Expired";
        readonly usageShowProvider: "Show {name} in sidebar";
        readonly usageDetails: "{name} quota details";
        readonly usageBack: "Back to all providers";
        readonly usageRefreshProvider: "Refresh {name}";
        readonly usageNoProviders: "No queryable providers";
        readonly usageNoneVisible: "No visible providers";
        readonly usageFilterHint: "Use the filter to choose which providers appear in the sidebar";
        readonly usageOpenFilter: "Open filter";
        readonly usageChooseProviders: "Choose sidebar providers";
        readonly usageRefreshAll: "Refresh all";
        readonly usageVisibility: "Sidebar visibility";
        readonly usageVisibilityHint: "Only affects Provider Usage, not the model list";
        readonly usageCloseFilter: "Close filter";
        readonly usageSearch: "Search providers";
        readonly usageShowAll: "Show all {n}";
        readonly usageNoMatch: "No matching providers";
        readonly usageReorder: "Reorder: {name}";
        readonly nav: "LLM Providers";
        readonly title: "LLM Providers";
        readonly subtitle: "Review account quota, then open an independent detail page to configure.";
        readonly empty: "Install Cursor, Grok, Codex, Ollama Cloud, CommandCode, or OpenCode Go to connect an account and pick models here.";
        readonly drag: "Reorder";
        readonly sort: "Sort providers";
        readonly done: "Done";
        readonly modelCount: "{n} models";
        readonly moveUp: "Move up";
        readonly moveDown: "Move down";
        readonly sidebarToggle: "Show in sidebar";
        readonly sidebarToggleHint: "Only the Task Panel quota block";
        readonly filterAll: "All";
        readonly filterLlm: "LLM";
        readonly filterAgent: "Agent";
        readonly details: "Details";
        readonly overview: "Back to overview";
        readonly connected: "Connected";
        readonly configured: "Configured";
        readonly unconnected: "Not connected";
        readonly unknown: "Checking…";
        readonly connectedCount: "Connected providers";
        readonly connectedHint: "Quota belongs to each account. Totals are not merged.";
        readonly colProvider: "Provider / connection";
        readonly colQuota: "Primary window · remaining";
        readonly windowHour: "5-hour window";
        readonly windowWeek: "Weekly window";
        readonly windowMonth: "Monthly window";
        readonly colConfig: "Setup";
        readonly systemZone: "System time zone";
        readonly breadcrumbOverview: "Quota overview";
        readonly quotaHeading: "Remaining quota";
        readonly quotaMeta: "Account remaining · each window is independent";
        readonly connectToSee: "Connect to see quota";
        readonly unsupportedQuota: "Quota is not available";
        readonly loadingQuota: "Reading quota…";
        readonly errorQuota: "Could not read quota";
        readonly resetAt: "Resets ";
        readonly resetOverdue: "Expired, waiting for update · ";
        readonly resetMissing: "{period} · reset time not provided";
        readonly refresh: "Refresh";
        readonly refreshing: "Refreshing";
        readonly accountHeading: "Account";
        readonly advancedHeading: "Advanced";
        readonly advancedNote: "Optional capabilities";
        readonly accountOauthMeta: "Subscription · no API key";
        readonly accountApiMeta: "API Key · saved keys are never echoed";
        readonly expandAll: "Expand all";
        readonly collapseAll: "Collapse all";
        readonly modelIdLabel: "Model ID";
        readonly modelNameLabel: "Display name";
        readonly addModelLabel: "Add model manually";
        readonly removeModelLabel: "Remove";
        readonly dragModelLabel: "Reorder";
        readonly modelsHeading: "Models";
        readonly modelsCount: "{n}";
        readonly modelsHint: "Names and IDs always show; expand a row for capacity and capability parameters.";
        readonly sortModels: "Sort";
        readonly chooseFromAccount: "Choose from account";
        readonly addModel: "Add model manually";
    };
};
export type ProviderSectionLocaleKey = keyof typeof copy.en;
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface SlotMap {
        'settings.provider.item': {
            kind: 'keyed';
            scope: 'root';
        };
    }
    interface LocaleNamespaceMap {
        'settings.providers': keyof typeof copy.en;
    }
}
//# sourceMappingURL=provider-section.d.ts.map